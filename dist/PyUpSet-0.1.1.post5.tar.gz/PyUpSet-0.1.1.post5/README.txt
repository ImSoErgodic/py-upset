A pure-python implementation of the UpSet suite of visualisation methods by Lex, Gehlenborg et al.

For more information on how to use the package, please consult the github homepage.
